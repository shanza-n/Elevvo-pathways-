import argparse
import os
import shutil
import sys
import time
from pathlib import Path
import logging

def setup_logging(log_path: Path, enable: bool):
    if enable:
        logging.basicConfig(
            filename=str(log_path),
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )
    else:
        logging.basicConfig(level=logging.CRITICAL)  # suppress logging output

def safe_move(src: Path, dest_dir: Path) -> Path:
    """Move *src* into *dest_dir*, handling name conflicts.
    If a file with the same name exists, append a timestamp before the extension.
    Returns the final destination path.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    if dest.exists():
        stem = src.stem
        suffix = src.suffix
        timestamp = time.strftime("_%Y%m%d_%H%M%S")
        new_name = f"{stem}{timestamp}{suffix}"
        dest = dest_dir / new_name
    shutil.move(str(src), str(dest))
    return dest

def organize_directory(target: Path, dry_run: bool, log_enabled: bool):
    if not target.is_dir():
        print(f"[ERROR] Target '{target}' is not a directory.")
        sys.exit(1)

    log_path = target / "organizer.log"
    setup_logging(log_path, log_enabled)

    for item in target.iterdir():
        if item.is_file():
            ext = item.suffix.lower().lstrip('.') or "no_ext"
            dest_dir = target / ext
            if dry_run:
                print(f"[DRY‑RUN] Would move {item.name} -> {dest_dir / item.name}")
                logging.info(f"DRY‑RUN move {item} -> {dest_dir / item.name}")
            else:
                try:
                    final_dest = safe_move(item, dest_dir)
                    print(f"Moved {item.name} -> {final_dest.relative_to(target)}")
                    logging.info(f"Moved {item} -> {final_dest}")
                except Exception as e:
                    print(f"[ERROR] Failed to move {item.name}: {e}")
                    logging.error(f"Failed to move {item}: {e}")
        else:
            # skip directories (including the ones we just created)
            continue

def main():
    parser = argparse.ArgumentParser(description="Organize files in a directory by extension.")
    parser.add_argument("target", type=str, help="Path to the directory to organize")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without moving files")
    parser.add_argument("--log", action="store_true", help="Enable logging to organizer.log in the target directory")
    args = parser.parse_args()

    target_path = Path(args.target).resolve()
    organize_directory(target_path, args.dry_run, args.log)

if __name__ == "__main__":
    main()
