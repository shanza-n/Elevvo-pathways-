import argparse
import json
import os
from datetime import datetime
from collections import defaultdict

DATA_FILE = os.path.join(os.path.dirname(__file__), "expenses.json")

def load_expenses():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_expenses(expenses):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(expenses, f, indent=2)

def add_entry(args):
    # Validate amount
    try:
        amount = float(args.amount)
        if amount <= 0:
            raise ValueError
    except ValueError:
        print("[ERROR] Amount must be a positive number.")
        return
    # Validate date format YYYY-MM-DD
    try:
        datetime.strptime(args.date, "%Y-%m-%d")
    except ValueError:
        print("[ERROR] Date must be in YYYY-MM-DD format.")
        return
    entry = {
        "amount": amount,
        "category": args.category,
        "date": args.date,
    }
    expenses = load_expenses()
    expenses.append(entry)
    save_expenses(expenses)
    print(f"Added expense: ${amount:.2f} | {args.category} | {args.date}")

def list_entries(_):
    expenses = load_expenses()
    if not expenses:
        print("No expenses recorded.")
        return
    print("--- Expense Log ---")
    for i, e in enumerate(expenses, 1):
        print(f"{i}. ${e['amount']:.2f} | {e['category']} | {e['date']}")

def monthly_summary(_):
    expenses = load_expenses()
    if not expenses:
        print("No expenses recorded.")
        return
    # Group by month (YYYY-MM)
    month_data = defaultdict(list)
    for e in expenses:
        month = e["date"][:7]  # YYYY-MM
        month_data[month].append(e)
    print("--- Monthly Summary ---")
    for month, items in sorted(month_data.items()):
        total = sum(i["amount"] for i in items)
        avg = total / len(items)
        # per‑category aggregation
        cat_totals = defaultdict(float)
        for i in items:
            cat_totals[i["category"]] += i["amount"]
        cat_str = ", ".join([f"{cat}: ${amt:.2f}" for cat, amt in cat_totals.items()])
        print(f"{month}: Total=${total:.2f}, Avg=${avg:.2f}, By Category=({cat_str})")

def main():
    parser = argparse.ArgumentParser(description="Simple CLI Expense Tracker")
    subparsers = parser.add_subparsers(dest="command")

    # add command
    add_parser = subparsers.add_parser("add", help="Add a new expense entry")
    add_parser.add_argument("amount", help="Expense amount (positive number)")
    add_parser.add_argument("category", help="Expense category (e.g., Food, Transport)")
    add_parser.add_argument("date", help="Date of expense in YYYY-MM-DD format")
    add_parser.set_defaults(func=add_entry)

    # list command
    list_parser = subparsers.add_parser("list", help="List all expense entries")
    list_parser.set_defaults(func=list_entries)

    # summary command
    summary_parser = subparsers.add_parser("summary", help="Show monthly summary report")
    summary_parser.set_defaults(func=monthly_summary)

    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        return
    args.func(args)

if __name__ == "__main__":
    main()
