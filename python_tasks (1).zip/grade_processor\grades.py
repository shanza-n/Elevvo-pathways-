"""grades.py – modular functions for student grade processing.

Provides:
- average(scores)
- highest(scores)
- lowest(scores)
- pass_fail(scores, passing=60)

All functions include type hints and raise InvalidScoreError for out‑of‑range values.
"""

from typing import List


class InvalidScoreError(ValueError):
    """Raised when a score is not between 0 and 100 inclusive."""

    def __init__(self, score: float):
        super().__init__(f"Invalid score {score!r}: must be between 0 and 100.")
        self.score = score


def _validate_scores(scores: List[float]) -> None:
    for s in scores:
        if not (0 <= s <= 100):
            raise InvalidScoreError(s)


def average(scores: List[float]) -> float:
    """Return the arithmetic mean of *scores*.

    Raises:
        InvalidScoreError: if any score is outside 0‑100.
    """
    _validate_scores(scores)
    if not scores:
        return 0.0
    return sum(scores) / len(scores)


def highest(scores: List[float]) -> float:
    """Return the highest score.

    Raises:
        InvalidScoreError: if any score is outside 0‑100.
    """
    _validate_scores(scores)
    return max(scores) if scores else 0.0


def lowest(scores: List[float]) -> float:
    """Return the lowest score.

    Raises:
        InvalidScoreError: if any score is outside 0‑100.
    """
    _validate_scores(scores)
    return min(scores) if scores else 0.0


def pass_fail(scores: List[float], passing: float = 60.0) -> List[bool]:
    """Return a list of booleans indicating pass (True) / fail (False).

    Args:
        scores: List of numeric scores.
        passing: Threshold score to be considered a pass.
    Raises:
        InvalidScoreError: if any score is outside 0‑100.
    """
    _validate_scores(scores)
    return [s >= passing for s in scores]
