# Python Tasks Collection

This repository contains three self‑contained, beginner‑friendly Python utilities that showcase core language features:

## 1. Expense Tracker (`expense_tracker/tracker.py`)
- **Features**: Add expense entries, list all entries, and display a monthly summary (totals, averages, per‑category breakdown).
- **Persistence**: Data is stored in `expenses.json` (created automatically on first run) using the standard `json` module.
- **Usage**:
  ```bash
  python -m expense_tracker.tracker add 12.50 Food 2024-10-31
  python -m expense_tracker.tracker list
  python -m expense_tracker.tracker summary
  ```
- **Validation**: Positive amount and ISO `YYYY‑MM‑DD` date format.

## 2. Grade Processor (`grade_processor/grades.py` + `grade_processor/demo.py`)
- **Modular functions** with type hints:
  - `average(scores)` – mean of a list of scores.
  - `highest(scores)` – highest score.
  - `lowest(scores)` – lowest score.
  - `pass_fail(scores, passing=60)` – boolean pass/fail list.
- **Custom exception** `InvalidScoreError` is raised for scores outside the 0‑100 range.
- **Demo script** (`demo.py`) shows how to import the module and handle exceptions.
- **Usage**:
  ```bash
  python -m grade_processor.demo
  ```

## 3. Automated File Organizer (`file_organizer/organizer.py`)
- **Purpose**: Scan a directory and move files into subfolders based on their extensions.
- **Safety**: Never overwrites existing files – appends a timestamp when a conflict occurs.
- **Options**:
  - `--dry-run` – preview actions without moving files.
  - `--log` – write detailed operation logs to `organizer.log` inside the target directory.
- **Usage**:
  ```bash
  python -m file_organizer.organizer /path/to/target
  python -m file_organizer.organizer /path/to/target --dry-run
  python -m file_organizer.organizer /path/to/target --log
  ```

---

All scripts are written for **Python 3.9+** and rely only on the standard library. Feel free to explore, extend, or integrate them into larger projects.
