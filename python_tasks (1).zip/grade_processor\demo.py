import json
from pathlib import Path
from .grades import average, highest, lowest, pass_fail, InvalidScoreError

def load_sample_scores() -> list:
    # Example data: list of student records (name, scores list)
    return [
        {"name": "Alice", "scores": [85, 92, 78]},
        {"name": "Bob", "scores": [58, 64, 70]},
        {"name": "Charlie", "scores": [100, 95, 98]},
    ]

def main():
    records = load_sample_scores()
    for rec in records:
        name = rec["name"]
        scores = rec["scores"]
        try:
            avg = average(scores)
            hi = highest(scores)
            lo = lowest(scores)
            passes = pass_fail(scores)
            pass_count = sum(passes)
            print(f"Student: {name}")
            print(f"  Scores: {scores}")
            print(f"  Average: {avg:.2f}, Highest: {hi}, Lowest: {lo}")
            print(f"  Passed {pass_count}/{len(scores)} subjects")
        except InvalidScoreError as e:
            print(f"Invalid score in record for {name}: {e}")

if __name__ == "__main__":
    main()
